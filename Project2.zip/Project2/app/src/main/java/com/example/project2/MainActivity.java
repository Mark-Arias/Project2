package com.example.project2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private ImageView image;
    private ImageButton leftButton;
    private ImageButton rightButton;
    private PictureGalleryFragment pictureFragment;
    int imageCount = 1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        image = (ImageView) findViewById(R.id.imageView);
        image.setImageResource(R.drawable.animal1);



        leftButton = findViewById(R.id.imageButtonLeft);
        rightButton = findViewById(R.id.imageButtonRight);

        rightButton.setOnClickListener(v -> {

            incrementImageCount();
            pictureFragment = PictureGalleryFragment.newInstance("animal",getImageCount());

            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.pictureGalleryFragment, pictureFragment);
            transaction.addToBackStack(null);
            transaction.commit();

        });

        leftButton.setOnClickListener(v -> {

            decrementImageCount();
            pictureFragment = PictureGalleryFragment.newInstance("animal",getImageCount());

            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.pictureGalleryFragment, pictureFragment);
            transaction.addToBackStack(null);
            transaction.commit();

        });


    }

    public int getImageCount() {
        return imageCount;
    }

    public void incrementImageCount() {
        if(imageCount < 8) {
            imageCount++;
        }
    }

    public void decrementImageCount() {
        if(imageCount > 1) {
            imageCount--;
        }
    }
}


